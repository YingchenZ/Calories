package com.example.calories;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.datatype.BmobDate;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;

public class MealActivity extends AppCompatActivity {
    private ImageView SettingButton;
    private ImageView CalendarButton;
    private ImageView MealButton;
    private ImageView SearchButton;
    private ImageView YesterdaySummaryButton;
    private ImageView HomeButton;

    private Button addBreakfast;
    private Button addLunch;
    private Button addDinner;

    // For the list
    private RecyclerView breakfastList;
    private RecyclerView.LayoutManager breakfastLayoutManager;
    private RecyclerView.Adapter breakfastAdapter;
    private ArrayList<Meal> todayBreakfast;

    private RecyclerView lunchList;
    private RecyclerView.LayoutManager lunchLayoutManager;
    private RecyclerView.Adapter lunchAdapter;
    private ArrayList<Meal> todayLunch;


    private RecyclerView dinnerList;
    private RecyclerView.LayoutManager dinnerLayoutManager;
    private RecyclerView.Adapter dinnerAdapter;
    private ArrayList<Meal> todayDinner;


    //    private void updateBreakfast(Meal meal){
//        todayBreakfast.add(meal);
//    }
    private ArrayList<Meal> getTodayBreakfast(){
        return todayBreakfast;
    }
    private BmobQuery<Meal> query = new BmobQuery<Meal>();
    private List<BmobQuery<Meal>> and = new ArrayList<BmobQuery<Meal>>();
    public MealActivity(){
        this.todayBreakfast = new ArrayList<Meal>();
        this.todayLunch = new ArrayList<Meal>();
        this.todayDinner = new ArrayList<Meal>();
//        BmobQuery<Meal> q1 = new BmobQuery<Meal>();
//        String start = "2021-02-15 00:00:00";
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        Date date  = null;
//        try {
//            date = sdf.parse(start);
//        } catch (ParseException e) {
//            e.printStackTrace();
//        }
//        q1.addWhereGreaterThanOrEqualTo("createdAt",new BmobDate(date));
//        and.add(q1);
//
//        BmobQuery<Meal> q2 = new BmobQuery<Meal>();
//        String end = "2021-02-15 23:59:59";
//        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        Date date1  = null;
//        try {
//            date1 = sdf1.parse(end);
//        } catch (ParseException e) {
//            e.printStackTrace();
//        }
//        q2.addWhereLessThanOrEqualTo("createdAt",new BmobDate(date1));
//        and.add(q2);
//        query.and(and);
//
//        query.findObjects(new FindListener<Meal>() {
//            @Override
//            public void done(List<Meal> list, BmobException e) {
////                todayBreakfast = (ArrayList<Meal>) list;
//                for(Meal meal : list){
//                    if(meal.getMealType().equals("Breakfast")){
//                        Log.d("count ", " = "+ meal.getMealName());
//                        updateBreakfast(meal);
////                        todayBreakfast.add(meal);
//                    }
//                }
//                Log.d("size ", " ...= "+getTodayBreakfast().size());
//            }
//        });
//        Log.d("size ", " = "+getTodayBreakfast().size());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal);
        // =========================== Get food list from bmob ===========================



        // =========================== Breakfast Section ===========================
        breakfastList = (RecyclerView)findViewById(R.id.breakfastList);
        breakfastList.setHasFixedSize(true);
        breakfastLayoutManager = new LinearLayoutManager(getApplicationContext());
        breakfastList.setLayoutManager(breakfastLayoutManager);

        BmobQuery<Meal> q1 = new BmobQuery<Meal>();
        // =================== Use the actual date ============================
        String start = "2021-02-15 00:00:00";
        // ====================================================================
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date  = null;
        try {
            date = sdf.parse(start);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        q1.addWhereGreaterThanOrEqualTo("createdAt",new BmobDate(date));
        and.add(q1);

        BmobQuery<Meal> q2 = new BmobQuery<Meal>();
        // =================== Use the actual date ============================
        String end = "2021-02-15 23:59:59";
        // ====================================================================
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date1  = null;
        try {
            date1 = sdf1.parse(end);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        q2.addWhereLessThanOrEqualTo("createdAt",new BmobDate(date1));
        and.add(q2);
        query.and(and);



//        breakfastAdapter = new GeneralMealAdapter(this, getTodayBreakfast());
//        breakfastList.setAdapter(breakfastAdapter);
        // add food to breakfast
        addBreakfast = findViewById(R.id.addBreakfastButton);
        addBreakfast.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent addFoodToBreakfast = new Intent(MealActivity.this, MealSearchActivity.class);
                Bundle newBundle = new Bundle();
                newBundle.putString("type", "Breakfast");
                addFoodToBreakfast.putExtras(newBundle);
                startActivity(addFoodToBreakfast);
            }
        });

        // =========================== Lunch Section ===========================
        lunchList = (RecyclerView)findViewById(R.id.lunchList);
        lunchList.setHasFixedSize(true);
        lunchLayoutManager = new LinearLayoutManager(getApplicationContext());
        lunchList.setLayoutManager(lunchLayoutManager);

        // add food to lunch
        addLunch = findViewById(R.id.addLunchButton);
        addLunch.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent addFoodToLunch = new Intent(MealActivity.this, MealSearchActivity.class);
                Bundle newBundle = new Bundle();
                newBundle.putString("type", "Lunch");
                addFoodToLunch.putExtras(newBundle);
                startActivity(addFoodToLunch);
            }
        });

        // =========================== Dinner Section ===========================
        dinnerList = (RecyclerView)findViewById(R.id.dinnerList);
        dinnerList.setHasFixedSize(true);
        dinnerLayoutManager = new LinearLayoutManager(getApplicationContext());
        dinnerList.setLayoutManager(dinnerLayoutManager);

        // add food to Dinner
        addDinner = findViewById(R.id.addDinnerButton);
        addDinner.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent addFoodToDinner = new Intent(MealActivity.this, MealSearchActivity.class);
                Bundle newBundle = new Bundle();
                newBundle.putString("type", "Dinner");
                addFoodToDinner.putExtras(newBundle);
                startActivity(addFoodToDinner);
            }
        });


        query.findObjects(new FindListener<Meal>() {
            @Override
            public void done(List<Meal> list, BmobException e) {
//                todayBreakfast = (ArrayList<Meal>) list;
                for(Meal meal : list){
                    if(meal.getMealType().equals("Breakfast")){
                        Log.d("count ", " = "+ meal.getMealName());
//                        updateBreakfast(meal);
                        todayBreakfast.add(meal);
                    }
                    if(meal.getMealType().equals("Lunch")){
                        todayLunch.add(meal);
                    }
                    if(meal.getMealType().equals("Dinner")){
                        todayDinner.add(meal);
                    }
                }
                breakfastAdapter = new GeneralMealAdapter(MealActivity.this, todayBreakfast);
                breakfastList.setAdapter(breakfastAdapter);

                lunchAdapter = new GeneralMealAdapter(MealActivity.this, todayLunch);
                lunchList.setAdapter(lunchAdapter);

                dinnerAdapter = new GeneralMealAdapter(MealActivity.this, todayDinner);
                dinnerList.setAdapter(dinnerAdapter);
//                Log.d("size ", " ...= "+getTodayBreakfast().size());
            }
        });






        // ======================== Setting page Button ========================
        SettingButton =  findViewById(R.id.imageViewSetting);
        SettingButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MealActivity.this, SettingActivity.class);
                startActivity(settingIntent);
            }
        });

        // ======================== Calendar page Button ========================
        CalendarButton =  findViewById(R.id.imageViewCalendar);
        CalendarButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MealActivity.this, CalendarActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Meal page Button ========================
        MealButton =  findViewById(R.id.imageViewMeal);
        MealButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MealActivity.this, MealActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Search page Button ========================
        SearchButton =  findViewById(R.id.imageViewSearching);
        SearchButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MealActivity.this, SearchActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Recommendation page Button ========================
        YesterdaySummaryButton =  findViewById(R.id.imageViewYesterdaySummary);
        YesterdaySummaryButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MealActivity.this, YesterdaysummaryActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Home page Button ========================
        HomeButton =  findViewById(R.id.imageViewHome);
        HomeButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MealActivity.this, MainActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });
    }
}