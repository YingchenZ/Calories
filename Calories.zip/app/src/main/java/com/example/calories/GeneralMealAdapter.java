package com.example.calories;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class GeneralMealAdapter extends RecyclerView.Adapter {
    private Context mycontext;
    private ArrayList<Meal> mealList = new ArrayList<Meal>();

    public GeneralMealAdapter(Context context, ArrayList<Meal> mealList ){
        mycontext = context;
        this.mealList = mealList;

    }

    public class MealViewHolder extends RecyclerView.ViewHolder{
        public TextView mealNameField, mealCalorieField;
        public MealViewHolder(@NonNull View itemView) {
            super(itemView);
            mealNameField = (TextView) itemView.findViewById(R.id.MealNameField);
            mealCalorieField = (TextView)itemView.findViewById(R.id.MealCalorieField);
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.meal_item_view,parent,false);
        MealViewHolder holder = new MealViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
//        String name = "Apple";
//        String cal = "100";
        String name = mealList.get(position).getMealName();
        String cal = String.valueOf(mealList.get(position).getTotalCalorie());
//        String name = (String) list.get(position)[0];
//        String cal = (String) list.get(position)[1];
//        Log.d("In.... size ", " = "+mealList.size());
        ((MealViewHolder) holder).mealNameField.setText(name);
        ((MealViewHolder) holder).mealCalorieField.setText(cal + " Kcal");
    }

    @Override
    public int getItemCount() {
        return mealList.size();

//        return 10;
    }
}
