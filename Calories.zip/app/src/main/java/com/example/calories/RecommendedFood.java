package com.example.calories;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

public class RecommendedFood extends RecyclerView.Adapter {
    private Context mycontext;

    public class RecommendViewHolder extends RecyclerView.ViewHolder{
        private TextView mealTitle, mealCalorie, mealProtein, mealFat, mealCarb;
        private ImageView mealImage;

        public RecommendViewHolder(@NonNull View itemView) {
            super(itemView);
            mealImage = itemView.findViewById(R.id.mealImage);
            mealTitle = itemView.findViewById(R.id.mealTitle);
            mealCalorie = itemView.findViewById(R.id.mealCalorie);
            mealProtein = itemView.findViewById(R.id.mealProtein);
            mealFat = itemView.findViewById(R.id.mealFat);
            mealCarb = itemView.findViewById(R.id.mealCarb);
        }
    }

    public RecommendedFood(Context context){
        mycontext = context;
    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.meal_recommendation_adapter,parent,false);
        RecommendedFood.RecommendViewHolder holder = new RecommendedFood.RecommendViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        // ================================== The part some be retrieved from an array/arraylist object ==================================
        String name = "Anchovies With Breadcrumbs & Scallions";
        String carbs = "0";
        String fat = "2";
        String protein = "4";
        String calorie = "38";
        String image = "https://spoonacular.com/recipeImages/fish-tagine-with-tomatoes-capers-and-cinnamon-2-111567.jpg";
        // ====================================================================================================================

        if(name.length() > 25){
            name = name.substring(0, 25) + "\n" + name.substring(25);
        }
        ((RecommendViewHolder) holder).mealTitle.setText(name);
        ((RecommendViewHolder) holder).mealCarb.setText(carbs);
        ((RecommendViewHolder) holder).mealFat.setText(fat);
        ((RecommendViewHolder) holder).mealProtein.setText(protein);
        ((RecommendViewHolder) holder).mealCalorie.setText(calorie);
        Glide.with(mycontext).load(image).into(((RecommendViewHolder) holder).mealImage);
    }

    @Override
    public int getItemCount() {
        // ================================== Replace with the actual size ==================================
        int actualSize = 10;
        // ==================================================================================================
        return actualSize;
    }
}
