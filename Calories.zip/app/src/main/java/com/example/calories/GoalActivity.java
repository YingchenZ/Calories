package com.example.calories;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class GoalActivity extends AppCompatActivity {
    private Spinner spinnerGoalType;
    private String[] items=   {"healthy","loose weight"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal);
        spinnerGoalType = findViewById(R.id.spinnergoaltype);


        ArrayAdapter<String> aa = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,items); //第二个参数表示spinner没有展开前的UI类型
        spinnerGoalType.setAdapter(aa);
    }
}