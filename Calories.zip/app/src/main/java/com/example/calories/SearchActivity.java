package com.example.calories;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class SearchActivity extends AppCompatActivity {
    private ImageView SettingButton;
    private ImageView CalendarButton;
    private ImageView MealButton;
    private ImageView SearchButton;
//    private ImageView YesterdaySummaryButton;
    private ImageView HomeButton;
    private RecyclerView resultFromAPI;
    private RecyclerView.LayoutManager layoutManager;
    private RecyclerView.Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        resultFromAPI = findViewById(R.id.recommendedMeal);
        resultFromAPI.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RecommendedFood(getApplicationContext());
        resultFromAPI.setAdapter(adapter);





        // ======================== Setting page Button ========================
        SettingButton =  findViewById(R.id.imageViewSetting);
        SettingButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(SearchActivity.this, SettingActivity.class);
                startActivity(settingIntent);
            }
        });

        // ======================== Calendar page Button ========================
        CalendarButton =  findViewById(R.id.imageViewCalendar);
        CalendarButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(SearchActivity.this, CalendarActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Meal page Button ========================
        MealButton =  findViewById(R.id.imageViewMeal);
        MealButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(SearchActivity.this, MealActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Search page Button ========================
        SearchButton =  findViewById(R.id.imageViewSearching);
        SearchButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(SearchActivity.this, SearchActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

//        // ======================== Recommendation page Button ========================
//        YesterdaySummaryButton =  findViewById(R.id.imageViewYesterdaySummary);
//        YesterdaySummaryButton.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v) {
//                Intent settingIntent = new Intent(SearchActivity.this, YesterdaysummaryActivity.class); // Should jump to the real destination
//                startActivity(settingIntent);
//            }
//        });

        // ======================== Home page Button ========================
        HomeButton =  findViewById(R.id.imageViewHome);
        HomeButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(SearchActivity.this, MainActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });
    }
}