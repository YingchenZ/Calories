package com.example.calories;

import cn.bmob.v3.BmobObject;

public class Meal extends BmobObject {
    private String mealType;
    private String mealName;
    private double totalCalorie;
    private double totalProtein;
    private double totalCarb;
    private double totalFat;

    public Meal(String type, String name, double calorie, double protein, double carb, double fat){
        mealType = type;
        mealName = name;
        totalCalorie = calorie;
        totalProtein = protein;
        totalCarb = carb;
        totalFat = fat;
    }

    public void setMealName(String mealName) {
        this.mealName = mealName;
    }
    public String getMealName() {
        return mealName;
    }

    public void setMealType(String mealType) {
        this.mealType = mealType;
    }
    public String getMealType() {
        return mealType;
    }

    public void setTotalCalorie(double totalCalorie) {
        this.totalCalorie = totalCalorie;
    }
    public double getTotalCalorie() {
        return totalCalorie;
    }

    public void setTotalCarb(double totalCarb) {
        this.totalCarb = totalCarb;
    }
    public double getTotalCarb() {
        return totalCarb;
    }

    public void setTotalFat(double totalFat) {
        this.totalFat = totalFat;
    }
    public double getTotalFat() {
        return totalFat;
    }

    public void setTotalProtein(double totalProtein) {
        this.totalProtein = totalProtein;
    }
    public double getTotalProtein() {
        return totalProtein;
    }
}
