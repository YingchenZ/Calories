package com.example.calories;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.RatingBar;
import android.content.SharedPreferences;

public class YesterdaysummaryActivity extends AppCompatActivity {
//    private ImageView HomeButton;
    private SharedPreferences mshare;
    private RatingBar caloriesbar;
    private RatingBar proteinbar;
    private RatingBar carbbar;
    private RatingBar fatbar;
    private final String lack = "was not satisfied. You should consider to consume more ";
    private final String exceeded = "was beyond what you actually need. You should consider to consume LESS ";
    private final String onPoint = "was satisfied. Good job!";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yesterdaysummary);
        mshare = getSharedPreferences("userdata",MODE_PRIVATE);
        // =========================== Rating Area ====================================
        caloriesbar = (RatingBar) findViewById(R.id.rateCaloriesstar);
        proteinbar = findViewById(R.id.rateProteinsstar);
        carbbar = findViewById(R.id.rateCarbstar);
        fatbar = findViewById(R.id.rateFatstar);
        //=============================input data (need to use an equation to get the actual number!!!!!)==============================
        float calories  = (float) 3.0, protein = (float) 4.4, carb = (float) 5.0, fat = (float) 4.6;
        //=======================================
        caloriesbar.setRating(calories);
       // setAnimation(caloriesbar, calories);
        proteinbar.setRating(protein);
        carbbar.setRating(carb);
        fatbar.setRating(fat);

        // ========================= Text Area =========================================
        final String greeting = "What's popping, " + (mshare.getString("gender","Male").equals("Male")? "Mr. ": "Ms. ") + mshare.getString("name","") + ",\n"
                                + "What a beautiful day! According to dietary intakes summary, your  \n";
        final String proteinComments = "\t * The target of protein ";
        // Add a online if statement here. If yesterday's protein is lower than target => + lack; if exceed => + exceed; otherwise, + onPonint
        final String carbComments = "\t * The target of carb ";
        // Add a online if statement here. If yesterday's protein is lower than target => + lack; if exceed => + exceed; otherwise, + onPonint
        final String fatComments = "\t * The target of fat ";
        // Add a online if statement here. If yesterday's protein is lower than target => + lack; if exceed => + exceed; otherwise, + onPonint
        final String calComments = "\t * The target of calorie ";
        // Add a online if statement here. If yesterday's protein is lower than target => + lack; if exceed => + exceed; otherwise, + onPonint
    }
}