package com.example.calories;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ValueAnimator;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.text.DecimalFormat;

import cn.bmob.v3.Bmob;

public class MainActivity extends AppCompatActivity {
    private ImageView SettingButton;
    private ImageView CalendarButton;
    private ImageView MealButton;
    private ImageView SearchButton;
    private ImageView YesterdaySummaryButton;
    private ImageView HomeButton;
    private SharedPreferences mshare;
    private TextView userName, userAge, userHeight, userWeight, userCurrentCal, userCurrentProtein, userCurrentCarb, userCurrentFat, targetCal, targetProtein, targetCarb, targetFat;
    private double calorie = 0.0, protein = 0.0, carb = 0.0, fat = 0.0;
    private final int MaleButtonID = R.id.ButtonMale, FemaleButtonID = R.id.ButtonFemale;
    private ProgressBar proteinBar, carbBar, fatBar, calorieBar;

    private void setAnimation(final ProgressBar view, final int mProgressBar) {
        ValueAnimator animator = ValueAnimator.ofInt(0, mProgressBar).setDuration(1000);

        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                view.setProgress((int) valueAnimator.getAnimatedValue());
            }
        });
        animator.start();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Bmob.initialize(this, "a63a92d8571fb7c2e677743252cb47dd");

        mshare = getSharedPreferences("userdata",MODE_PRIVATE);
        userName = findViewById(R.id.TvNameField);
        userAge = findViewById(R.id.TvAgeField);
        userHeight = findViewById(R.id.TvHeightField);
        userWeight = findViewById(R.id.TvWeightField);

        userCurrentCal = findViewById(R.id.CurrentCal);
        userCurrentCarb = findViewById(R.id.CurrentCarb);
        userCurrentFat = findViewById(R.id.CurrentFat);
        userCurrentProtein = findViewById(R.id.CurrentProtein);
        targetCal = findViewById(R.id.TargetCal);
        targetCarb = findViewById(R.id.TargetCarb);
        targetFat = findViewById(R.id.TargetFat);
        targetProtein = findViewById(R.id.TargetProtein);


        userName.setText((mshare.getString("gender","Male").equals("Male")? "Mr. ": "Ms. ") + mshare.getString("name",""));
        userAge.setText("Age: " + mshare.getString("age","0"));
        userHeight.setText(mshare.getString("height","0.0") + "CM");
        userWeight.setText(mshare.getString("weight","0.0") + "Kg");

        double weight = Double.parseDouble(mshare.getString("weight","0.0"));
        double height = Double.parseDouble(mshare.getString("height","0.0"));
        int age = Integer.parseInt(mshare.getString("age","0"));
//        calorie = Double.parseDouble(mshare.getString("calorie", "0.0"));
//        protein = Double.parseDouble(mshare.getString("protein", "0.0"));
//        carb = Double.parseDouble(mshare.getString("carb", "0.0"));
//        fat = Double.parseDouble(mshare.getString("fat", "0.0"));

        if(mshare.getString("gender","Male").equals("Male")){
            calorie = 66.47 + (13.75 * weight) + (5.003 * height) - (6.755 * age);
        }
        else{
            calorie = 655.1 + (9.563 * weight) + (1.85 * height) - (4.676 * age);
        }
        calorie = Double.parseDouble(new DecimalFormat("###.00").format(calorie));
        protein = calorie * 0.4 / 4;
        protein = Double.parseDouble(new DecimalFormat("###.00").format(protein));
        carb = calorie * 0.4 / 4;
        carb = Double.parseDouble(new DecimalFormat("###.00").format(carb));
        fat = calorie * 0.2 / 4;
        fat = Double.parseDouble(new DecimalFormat("###.00").format(fat));




        // =================== Replace with the real data ===================
        double currentCal = 100.00, currentProtein = 100.00, currentCarb = 100.00, currentFat = 50.00;
        // ==================================================================
        calorieBar = findViewById(R.id.caloriesProgessBar);
//        calorieBar.setProgress((int) ((currentCal / calorie) * 100));
        setAnimation(calorieBar, (int) ((currentCal / calorie) * 100));
        proteinBar = findViewById(R.id.proteinProgressBar);
        setAnimation(proteinBar, (int) ((currentProtein / protein) * 100));
//        proteinBar.setProgress((int) ((currentProtein / protein) * 100));
        carbBar = findViewById(R.id.carbsProgressBar);
        setAnimation(carbBar, (int) ((currentCarb / carb) * 100));
//        carbBar.setProgress((int) ((currentCarb / carb) * 100));
        fatBar = findViewById(R.id.fatProgessBar);
        setAnimation(fatBar, (int) ((currentFat / fat) * 100));
//        fatBar.setProgress((int) ((currentFat / fat) * 100));


        userCurrentCal.setText(String.valueOf(currentCal));
        userCurrentCarb.setText(String.valueOf(currentCarb));
        userCurrentFat.setText(String.valueOf(currentFat));
        userCurrentProtein.setText(String.valueOf(currentProtein));
        targetCal.setText(String.valueOf(calorie) +"Kcal");
        targetCarb.setText(String.valueOf(carb) + "g");
        targetFat.setText(String.valueOf(fat) + "g");
        targetProtein.setText(String.valueOf(protein) + "g");
//        userCalTracking.setText( String.valueOf(currentCal) + " / "+ String.valueOf(calorie) +" Kcal");
//        userProteinTracking.setText(String.valueOf(currentProtein) + " / " + String.valueOf(protein) + "g");
//        userCarbTracking.setText(String.valueOf(currentCarb) + " / "+ String.valueOf(carb) + "g");
//        userFatTracking.setText(String.valueOf(currentFat) + " / "+ String.valueOf(fat) + "g");



        // ======================== Setting page Button ========================
        SettingButton =  findViewById(R.id.imageViewSetting);
        SettingButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MainActivity.this, SettingActivity.class);
                startActivity(settingIntent);
            }
        });

        // ======================== Calendar page Button ========================
        CalendarButton =  findViewById(R.id.imageViewCalendar);
        CalendarButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MainActivity.this, CalendarActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Meal page Button ========================
        MealButton =  findViewById(R.id.imageViewMeal);
        MealButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MainActivity.this, MealActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Search page Button ========================
        SearchButton =  findViewById(R.id.imageViewSearching);
        SearchButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MainActivity.this, SearchActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Recommendation page Button ========================
        YesterdaySummaryButton =  findViewById(R.id.imageViewYesterdaySummary);
        YesterdaySummaryButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MainActivity.this, YesterdaysummaryActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

        // ======================== Home page Button ========================
        HomeButton =  findViewById(R.id.imageViewHome);
        HomeButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent settingIntent = new Intent(MainActivity.this, MainActivity.class); // Should jump to the real destination
                startActivity(settingIntent);
            }
        });

    }


}